import re , yaml, enum, typing, decimal
from abc import ABC, abstractmethod


# Alp: Lib variables
parameters ={}
with open(r'/home/ec2-user/SageMaker/demo/middlelayer/metadata/sop_sections.yaml', 'r') as  yml:
        parameters = yaml.safe_load(yml)

# import pdb; pdb.set_trace()

patternNumbered = r'\d+(?:\.\d+)*[\s\S]*?[a-zA-Z]+\s?\.?(?=\s*(?:\d+|$))'
patternBulleted = r'*'
bullutedCodes = ['\uf0b7','\u2022', '\u2023', '\u25E6', '\u2043','\u2219']

# Alp: following is PrivateCode: CorrectCode
# TODO: check the model atributes to make sure different formats would have same private unicodess
wrongEncodes = {
        '\uf0a3': '\u2264',
        '\uf06d': '\u00b5',
        '\uf0b4': '\u0058',
        '\uf0e2': '\u00AE',
        '\uf0b1': '\u00B1',
        '\uf0b3': '\u2265'
}


# Alp: enum layer    
class ListStrategy(enum.Enum):

    AsIs = 1
    WithPrefix = 3
    WithOutPrefix = 5
        


class Helper:
    
    @staticmethod
    def genericGenerator():
        pass

    @staticmethod
    def getSOPSectionNames(sop_section: str):
        return parameters[sop_section]['sop names']

    @staticmethod
    def numberExtract(line: str):
        number_match = re.match(r'[0-9]{1,2}(\.[0-9]{1,2})*', line)

        if number_match is not None:
            number = number_match[0]
            title = re.split(number_match.group(0), line)[1].strip()
        
        return (number, title) if number_match is not None else (None, line.strip())

    @staticmethod
    def isLooksLikeSubTopic(previousTitle: typing.Union[dict, None], currentTopic: str, currentType : str, 
                currentOrder: typing.Union[str, None]):
        previousTitleNumber = previousTitle['RootNumber']

        previous = float(previousTitleNumber) if previousTitleNumber is not None else None
        current = float(currentOrder) if currentOrder is not None else None

        # TODO: consider not if - else since subtask can be not substring of Parent ans having no item number
        # if current is one of the Parent and It's all upper , to support LAB-2448 5.0 EQUIPMENTS 
        # case: subtitle has no number but parent has
        if currentTopic in previousTitle['Text']:
            return True
        elif  (current or 0) - (previous or 0) == 0.1:
           
            return True


    @staticmethod
    def isLooksLikeSeqTopic(previousTitle: typing.Union[dict, None], currentText: str):
        currentNumber, currentTopic = Helper.numberExtract(currentText)
        if currentNumber is None or currentTopic is None  or currentTopic == '': return False

        try:
            currentNumber  = decimal.Decimal(currentNumber)
            previous = decimal.Decimal(previousTitle['RootNumber'])
        except Exception as err:
            print(f"Previous Topic or Current Sub Topic has no number. Error:{err}")
            # print(f'Previous:{previousTitle}')
            # print(f'Current Text:{currentText}')
            return False
            # exit(1)
        
        return (currentNumber - previous) < 1


    @staticmethod
    def find_topic_by_key(dict_to_search: dict ,topic_name: str):
        for k, v in dict_to_search.items():
            if isinstance(v,dict):
                yield from Helper.find_topic_by_key(v, topic_name)
            elif k == topic_name:
                yield v
                
    @staticmethod
    def isListBulleted(sectionToParse: str):
        """
        Returns tuple of (bool, code or None)
        """
        # TODO: if starts with  or \uf0b7 in first 6 character
        # Enough for PoC but Regex would be better for prod

        for code in (*bullutedCodes,):
           if sectionToParse.startswith(code, 0, 5): 
               return ( True, code)

        return (False , None)

    @staticmethod
    def splitList(content: str):
        output = []
        isBulleted , code = Helper.isListBulleted(content)

        # better to have two seperate func to call, but for PoC having them in one location would be fine
        if isBulleted:            
            output.append([line.strip() for line in content.split(code if isBulleted else '\uf0b7')[1:]]) 
        else:
            matcher = re.finditer(patternNumbered, content)
            for match in matcher:
                output.append(match.group(0))

        return output
        

    @staticmethod
    def filterOutBlackList(content: str):
        '''
        returns empty string '' if entire content part of the following cases, otherwise content returns as is

        Case 1:
            Example: 
            Pfizer Confidential2of   OR Pfizer Confidential18of

            1.1 Pfizer Confidential is begining of  the line
            1.2. after that there is a numeric value following of

        Case 2: page numbers are in model ouput as stand alone data
            Example:
                8 OR 18 OT 21
            2.1: they are maz 2 digit numer as 18 , 19 or 5 (since we don't have any SOP that has more than 99 pages)        
            NOT: pattern set to have 2 digit number in given text

        case 3:  Confidential11of 18  , SOP 2448

        case 4:  Pfizer

        Case 5: Pfizer Confidential11of 18 \uf0b7 
                NOTE:SOP 2448 8.4 Identity Determination, giving above in the List 
        '''
        return re.sub(r'(^Pfizer Confidential(.*?)\d+of$)|(^Pfizer Confidential(.*?)\d+of\s+\d{1,2}\s)|(^\d{1,2}\s*$)|(^Pfizer$)|(^Confidential(.*?)\d+of\s+\d+)|(^\d{1,2}of\s)', r'', content)


    @staticmethod
    def fixModelEncodingIssues(content: str):
        for key in wrongEncodes.keys():
            content = re.sub( f'{key}', f'{wrongEncodes[key]}',content)

        return content

class Policy(ABC):

    @abstractmethod
    def parseOut(self, sectionToParse: str):
        pass

class PolicyListWithPrefix(Policy):    

    def parseOut(self, sectionToParse: str):
        return Helper.splitList(sectionToParse)


class PolicyDefault(Policy):

    def parseOut(self, sectionToParse: str) -> str:
        return str(sectionToParse)

class PolicyTextDefault(Policy):

    def parseOut(self, sectionToParse: str) -> str:
        return str(sectionToParse)


class Context:

    strategy :Policy

    def setPolicy(self, sop_section: str, content_type: str) -> None:
        pass
          

    def executePolicy(self, sop_section: str, section_content: str, content_type: str) -> str:
        self.__setPolicy(sop_section, content_type)

        return self.strategy.parseOut(section_content)            


    def __setPolicy(self, sop_section:str, content_type: str):
        parameter = parameters[sop_section][content_type.lower()]

        if content_type == 'List':
            if parameter == "WithPrefix":
                self.strategy = PolicyListWithPrefix()
            else:
                self.strategy = PolicyDefault()

        elif content_type == 'Text':
            if parameter == "default":
                self.strategy = PolicyTextDefault()
            else:
                self.strategy = PolicyDefault()
        
        elif content_type == 'Table':
            self.strategy = PolicyTextDefault()

        elif content_type == 'Figure':
            self.strategy = PolicyTextDefault()
        
        else:
            self.strategy = PolicyTextDefault()


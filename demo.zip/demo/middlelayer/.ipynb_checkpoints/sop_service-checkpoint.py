import json, yaml, types, datetime, argparse, pathlib, mitm

# !!! <PARAMS START>
config = {}
fileNo = ""
DEBUG = False
TYPE_ATTRIBUTE = ""
# !!! <PARAMS END>

def getSectionName(sop_section_name: str) -> str:
    return  config[sop_section_name]['rename'] if any('rename' in x for x in config[sop_section_name])  else sop_section_name


def doYAML(yamlPath: str) -> dict:
    try:
        with open(f'{yamlPath}', 'r') as yml:
            my_config = yaml.safe_load(yml)

    except FileNotFoundError:
        print(f"Given YAML file does not exist")
        exit(1)
        
    return my_config


def dumpJSON(sop_sections: dict, filePrefix: str = None):
    try:
        with open(f"{appArgs.output_folder}{'Sample' if filePrefix is None else filePrefix}-{fileNo}.json", "w" , encoding="UTF-8") as output:
            json.dump(sop_sections, output, indent=4, ensure_ascii= False)
        
        print(f"JSON output for {fileNo} created.")
    except Exception as e:
        print(f"Output JSON file couldn't written.Error:{e}")
        exit(1)
    


def doExtraction(inputPath:str):
    # TODO: reading json and loading contant to dict should be seperate func
    try:
        with open(inputPath, 'r',  encoding="utf-8") as f:
            modelOutput = json.load(f)

        print(f"Model Ouput loaded ...")

    except FileNotFoundError as err:
        print(f"Source Model Output file does not exist. Error:{err}")
        exit(1)

    except Exception as err:
        print(f"Error for source Model Output file read. Error:{err}")
        exit(1)

    # TODO: following changed to iterate over the pages since model output changed to support header section
    # iteration should support earlier(pages on) and current style (pages, header)
    pairs = [
        (key, value) for key, values in modelOutput['pages'].items()
        for value  in values
    ] if 'pages' in modelOutput else [
        (key, value) for key, values in modelOutput.items()
        for value  in values
    ]

    titles = {}
    selections = ("List", 'Text', 'Table', 'Figure')
    
    previousSection =""
    previousSubSection=""
    for pair in pairs:
        if pair[1][f'{TYPE_ATTRIBUTE}'] == 'Title':            
            orderNumber, title = mitm.Helper.numberExtract(pair[1]['text'])
            # assumption. ROOT section is always UPPER
            if isinstance(pair[1]['text'], str) and pair[1]['text'].isupper():               
                # if looks likely sub topic , add it to previous topic and move forward
                # option 1. titles(dict in case having first item) does exist, and text is string, and isLooksLikeSubTopic is True
                if titles and isinstance(pair[1]['text'], str) and mitm.Helper.isLooksLikeSubTopic(titles[previousSection] if previousSection in titles else None, title, pair[1][f'{TYPE_ATTRIBUTE}'], orderNumber):              
                    subDict = {}
                    subDict['RootNumber'] = orderNumber
                    subDict['RootType'] = 'child'
                    subDict['Text'] = title                    
                    subDict['Content'] = list()                    
                    titles[previousSection]['Content'].append(subDict)
                    previousSection = previousSection
                    previousSubSection =  title
                    continue

                # that must be the root section
                titles[title] = dict() 
                titles[title]['RootNumber'] = orderNumber
                titles[title]['RootType'] = 'Parent'
                titles[title]['Text'] = title
                titles[title]['Content'] = list()
                previousSection = title
                if DEBUG: print(f'number:{orderNumber if orderNumber is not None else ""}  , Title:{title}')                

        # Option 2. title does exist, and orderNumber does exist, type is title (final_type can be wrong)
        elif previousSection and titles[previousSection] and titles[previousSection]['RootType'] == "Parent" and pair[1]['type'] in ['Title','Text'] and mitm.Helper.isLooksLikeSeqTopic(titles[previousSection], pair[1]['text']):              
            orderNumber, title = mitm.Helper.numberExtract(pair[1]['text'])
            if DEBUG: print(f'Sub Topic detected: {title}')
            subDict = {}
            subDict['RootNumber'] = orderNumber
            subDict['RootType'] = 'child'
            subDict['Text'] = title                    
            subDict['Content'] = list()                    
            titles[previousSection]['Content'].append(subDict)
            previousSection = previousSection
            previousSubSection =  title
            continue

        elif pair[1][f'{TYPE_ATTRIBUTE}'] in selections:
            # clean up the text if content has item in Black List
            cleanedUpText = mitm.Helper.filterOutBlackList(pair[1]['text'])
            if not cleanedUpText: continue
            # Alp: should be in bulk way not against to every incoming text
            cleanedUpText = mitm.Helper.fixModelEncodingIssues(cleanedUpText)
            if previousSection in titles:
                if isinstance(titles[previousSection]['Content'], list ):
                    targetSub = next((sub for sub in titles[previousSection]['Content'] if isinstance(sub, dict) and sub['Text'] == previousSubSection), None)
                    if previousSubSection and targetSub:
                        # previous is sub
                        targetSub['Content'].append((pair[1][f'{TYPE_ATTRIBUTE}'], cleanedUpText))        
                        continue

                titles[previousSection]['Content'].append((pair[1][f'{TYPE_ATTRIBUTE}'], cleanedUpText))        

    # if DEBUG: print(f'existing sections in SOP: {titles.keys()}')
    if DUMP_FIRST_JSON : dumpJSON(titles, "PreProc")


    targetJSON ={}
    targetJSON['SOP File'] = f"{fileNo}"
    targetJSON['MitM Version'] = config['version']
    targetJSON['Extraction Time'] = datetime.datetime.now().strftime(r"%m/%d/%Y %H:%M:%S")
    # TODO: Header w/ Doc-Name and Title should be here
    targetJSON['Header'] = modelOutput['header']

    for section in config['selected sections']:
        if config[section]:
            if DEBUG: print(f'Running: {section}')
            keyForJson = getSectionName(section)            
            sop_names = mitm.Helper.getSOPSectionNames(section, config)
            section_content = [titles[x] for x in sop_names if x in titles]
            # if DEBUG: print(f'section content:{section_content}')
            for sub_content in section_content:                 
                counter = 0
                if isinstance(sub_content, dict):
                    tst = mitm.Context(config)

                    #Alp: two main option 
                    # 1. COntent section would be list of tuples to fill into the new JSON
                    # 2. Content section would be list of Dict means one level sub/inner object to fill into the new JSON
                    #     then we hould iter in dict's list   
                    
                    if isinstance(sub_content['Content'], list):           
                        counter = 0                                     
                        for innerItem in sub_content['Content']:
                            #OPTION 1
                            if isinstance(innerItem, tuple):                                
                                if targetJSON.get(keyForJson) is None: targetJSON[keyForJson] = list()
                                output = tst.executePolicy(section, innerItem[1], innerItem[0])
                                targetJSON[keyForJson].append(output)                                        
                                counter += 1                 
                            #OPTION 2
                            elif isinstance(innerItem, dict):
                                # we have the title to use as Key
                                # we have the List in COntent to iter and add to this inner dict
                                if targetJSON.get(keyForJson) is None: targetJSON[keyForJson] = list()
                                tmpDict = {}
                                tmpDict[innerItem['Text']] = list()
                                # innerItem['Content'] is list of Tuples
                                for itemToAdd in innerItem['Content']:                                    
                                    output = tst.executePolicy(section, itemToAdd[1], itemToAdd[0])
                                    tmpDict[innerItem['Text']].append(output)
                                    counter += 1

                                targetJSON[keyForJson].append(tmpDict)

                        if DEBUG : print( f'ADDED CONTENT {counter}')

            if DEBUG : print(f'{" ": >10}{section} Content #: {counter}')                    
        
    dumpJSON(targetJSON)    

if __name__ == "__main__":
    DEBUG = False
    DUMP_FIRST_JSON = False
    TYPE_ATTRIBUTE = "final_type"
    

    argParser = argparse.ArgumentParser()
    argParser.add_argument('--input_file', type=str, required= True, help="Model Output file")
    argParser.add_argument('--yaml_file', type=str, default="/home/ec2-user/SageMaker/demo/middlelayer/metadata/sop_sections.yaml" , help="YAML file contains the app param")
    argParser.add_argument('--output_folder', type=str, required=True, help="Output JSON folder location")
    appArgs = argParser.parse_args()

    if appArgs:
        fileNo =  pathlib.Path(appArgs.input_file).stem
        config =  doYAML(appArgs.yaml_file)

    else:
        print("Application param does not exits")
        exit(1)

    print(f"Started For {appArgs.input_file}")
    # GC        => 106739  SOP-13024  SOP-109267 : 2 parag in SCOPE   , SOP-106739
    # andover   => LAB-2352  LAB-22059 , LAB-2352  LAB-2448
    
    doExtraction(appArgs.input_file)

import numpy as np
import pandas as pd
import cv2
import matplotlib.pyplot as plt
import layoutparser as sop
from model import model_TT, model_table, sop

def extract_line(df_ocr, df_area):
    data=[]
    bold=[]
    for idn,model_row in df_area.iterrows():
        tp_bbx=[0,int(model_row.y_1),int(model_row.page_width),int(model_row.y_2)]
        words= []
        is_bold = []
        for idx,ocr_row in df_ocr.iloc[:,:4].iterrows():
            word_bbx=ocr_row.astype(int).values
            flag=check_point(tp_bbx,word_bbx)
            if flag:
                words.append(df_ocr.iloc[idx]['text'].strip())
                is_bold.append(df_ocr.iloc[idx]['is_bold'])
        bold.append(is_bold)
        data.append(words)
    return data,bold


def check_title(df):
    final=[]
    for i,row in df.iterrows():
        if row.type in ['Title','text']:
            if (row.is_upper==True) and (row.word_length<5): # and (row.is_bold==True):
                final.append("Title")
            else:
                final.append("Text")
        else:
             final.append(row.type)
    df["final_type"] = final
    return df

def is_header_footer(ocr_df):
    ocr_df["combine_info"]= ocr_df[['x_1','y_1','x_2','y_2','text','height','width']].apply(lambda x: ','.join([str(p) for p in x]) ,axis=1)
    ocr_df["is_header_footer"]=ocr_df.combine_info.duplicated()
    return ocr_df

def is_bulit(ocr_df):
    title_index=["1.0",'2.0','3.0','4.0','5.0','6.0','7.0','8.0','9.0','10.0']
    ocr_df['is_start_bulit']=ocr_df.text.apply(lambda x : x in title_index)
    return ocr_df

# word
def get_center(x1,y1,x2,y2):
    xCenter = (x1 + x2) / 2
    yCenter = (y1 + y2) / 2
    return xCenter,yCenter

def FindPoint(x1, y1, x2,
              y2, x, y) :
    if (x > x1 and x < x2 and
        y > y1 and y < y2) :
        return True
    else :
        return False

def check_point(tt_box,word_bbx):
    point_x,point_y = get_center(word_bbx[0],word_bbx[1],
                                 word_bbx[2],word_bbx[3])
    return FindPoint(tt_box[0],tt_box[1],
                     tt_box[2],tt_box[3],point_x,point_y)

def extract_words(df_ocr, page_index, layout_df):
    df_ocr=df_ocr[df_ocr.page_index==page_index]
    df_area = layout_df.sort_values(by=['y_1'], ascending=True)
    data=[]
    for idn,model_row in df_area.iterrows():
        tp_bbx=[0,int(model_row.y_1),int(model_row.page_width),int(model_row.y_2)] #model_row[:4].astype(int).values
        para_data = {}
        word_index=[]
        words= []
        for idx,ocr_row in df_ocr.iloc[:,:4].iterrows():
            word_bbx=ocr_row.astype(int).values
            flag=check_point(tp_bbx,word_bbx)
            if flag:
                word_index.append(idx)
                words.append(df_ocr.iloc[idx]['text'])
                
        para_data["page_index"]=model_row.page_index
        para_data["type"]=model_row.type
        para_data["final_type"]=model_row.final_type
        content=" ".join([df_ocr.iloc[x]['text'] for x in word_index])
        para_data['text']=content
        data.append(para_data)
    
    return data

def mask_image(df,page_image):
    for x in df.iloc[:,:4].astype(int).values:
        page_image = cv2.rectangle(page_image, tuple(x[:2]),tuple(x[2:]),[255,255,255],-1)
    return page_image

def clean_image(image, ocr_df, page_index):
    page_id=page_index
    ocr_df=is_bulit(ocr_df)
    ocr_df=is_header_footer(ocr_df)
    select_page = ocr_df[ocr_df.page_index==page_id]
    remove_header_footer = select_page[select_page.is_header_footer==True]
    remove_bulit = select_page[select_page.is_start_bulit==True]
    
    image_header=mask_image(remove_header_footer, image)
    _image = mask_image(remove_bulit, image_header)
    
    return _image


def correct_df_area(page_ocr,page_index,page_area):
    page_ocr=page_ocr[page_ocr.page_index==page_index]
    sent,bold=extract_line(page_ocr,page_area)
    page_area["data"]=sent
    page_area["is_bold"]=[all(list_bold) for list_bold in bold]
    page_area["clean_data"]=[" ".join(x) for x in sent]
    page_area['word_length']=page_area.data.apply(lambda x: len(x))
    page_area['is_upper']=page_area.clean_data.apply(lambda x: x.isupper())
    update_df=check_title(page_area)
    update_df["is_duplicate"]=update_df.clean_data.duplicated()
    
    return update_df[update_df.is_duplicate==False]


def load_ocr(filename=None):
    pdf_layout, pdf_images = sop.load_pdf(filename,load_images=True)
    ocr_data=[]
    for page_index,ocr in enumerate(pdf_layout):
        image=np.array(pdf_images[page_index])
        df=ocr.to_dataframe()
        df["page_index"]=page_index
        df["height"] = abs(df.y_1-df.y_2)
        df['width'] = abs(df.x_1-df.x_2)
        df['page_width'] = image.shape[1]
        df['page_height'] = image.shape[0]
        df['clen_type']=df.type.apply(lambda x: x.lower())
        df['is_bold']=df.clen_type.str.contains('bold')
        ocr_data.append(df)
    ocr_df=pd.concat([x for x in ocr_data])
    return ocr_df,pdf_images
    

def layout_model(image,page_index=0, table=True):
    if table:
        table_layout=model_table.detect(image)
        image=mask_image(table_layout.to_dataframe(),image)
        table_layout= table_layout.to_dataframe()
    layout=model_TT.detect(image)
    df=layout.to_dataframe()
    df = pd.concat([df,table_layout])
    df["page_index"] = page_index
    df["height"] = abs(df.y_1-df.y_2)
    df['width'] = abs(df.x_1-df.x_2)
    df['page_width'] = image.shape[1]
    df['page_height'] = image.shape[0]
    df = df.sort_values(by=['y_1'], ascending=True)
    return df

def line_by_first_bbx(line_df,ocr_df,hight=0):
    tp_bbx=[0,int(line_df.y_1-hight),int(line_df.page_width),int(line_df.y_2+hight)]
    words= []
    for idx,ocr_row in ocr_df.iloc[:,:4].iterrows():
        word_bbx=ocr_row.astype(int).values
        flag=check_point(tp_bbx,word_bbx)
        if flag:
            words.append(idx)
    _line=ocr_df.loc[words]
    return _line.sort_values(by=['x_1'], ascending=True)

def Convert(a):
    it = iter(a)
    res_dct = dict(zip(it, it))
    return res_dct

def header_extraction(ocr_df):
    ocr_df=is_header_footer(ocr_df)
    header=ocr_df[(ocr_df.is_header_footer==True) & (ocr_df.page_index==2)]
    header[["x_1","y_1","x_2","y_2"]]=header[["x_1","y_1","x_2","y_2"]].astype(int)
    
    header=ocr_df[(ocr_df.is_header_footer==True) & (ocr_df.page_index==2)]
    header[["x_1","y_1","x_2","y_2"]]=header[["x_1","y_1","x_2","y_2"]].astype(int)
    line1=header[(header.text=="Status") & (header.is_bold==True)]
    line2=header[(header.text=="Title") & (header.is_bold==True)]
    first_line=line_by_first_bbx(line1,header)
    title=line_by_first_bbx(line2,header,abs(line2.y_1-line2.y_2))

    header_list={"Status":"Status","Effective Date":"Effective-Date","Version":"Version","Doc Name":"Doc-Name"}

    raw=" ".join(first_line.text)
    for k,v in header_list.items():
        raw=raw.replace(k,v)
    header_dict=Convert(raw.split())
    title_text=" ".join(title.sort_index().text).replace('Title','').strip()
    header_dict["Title"]=title_text
    return header_dict
